﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour {
    //距离
    public float distance = 15;
    //横向角度
    public float rot = 0;
    //纵向角度
    private float roll = 30f * Mathf.PI * 2 / 360;
    //目标物体
    private GameObject target;

    // Use this for initialization
    void Start () {
        //找到主人公
        target = GameObject.Find("MainFish");
        //SetTarget.(GameObject.Find("MainFish"));
    }

    // Update is called once per frame
    void Update () {
		
	}

    void LateUpdate()
    {
        //一些判断
        if (target == null)
            return;
        if (Camera.main == null)
            return;
        //目标的坐标
        Vector3 targetPos = target.transform.position;
        //用三角函数计算相机位置
        Vector3 cameraPos;
        float d = distance * Mathf.Cos(roll);
        float height = distance * Mathf.Sin(roll);
        cameraPos.x = targetPos.x + d * Mathf.Cos(rot);
        cameraPos.z = targetPos.z + d * Mathf.Sin(rot);
        cameraPos.y = targetPos.y + height;
        Camera.main.transform.position = cameraPos;
        //对准目标
        Camera.main.transform.LookAt(target.transform);
    }

}
