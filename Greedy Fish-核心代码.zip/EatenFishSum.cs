﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EatenFishSum : MonoBehaviour {
    int sum = 0;

    //定义text
    Text myfishsum;

    // Use this for initialization
    void Start () {
        GameObject music = GameObject.Find("UI EmptyObject");
        myfishsum = music.transform.Find("Canvas").Find("FishSum").Find("MyFishSum").GetComponent<Text>();
    }
	
	// Update is called once per frame
	void Update () {
        myfishsum.text = sum + "条";
    }
    void OnCollisionEnter(Collision col)
    {
        EatenSum();
        //Debug.Log(sum);
    }

    void EatenSum() {
        sum++;
    }
}
