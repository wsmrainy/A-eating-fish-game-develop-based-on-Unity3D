﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateFishMove : MonoBehaviour {
    public Transform boxRange;  // 生成物体的范围
    public GameObject prefab;   // 生成物体的预制体
    public Transform parent;    // 将物体放到哪个父节点下
    public int maxNum;          // 生成的数量

    private float timer = 0f;   // 当前计时器的时间
    private float spawnTime = 0.01f;// 多少时间生成1个物体
    private int sum = 0;        // 当前物体总数

    private void Update()
    {
        // 获取实例化物体的个数
        timer += Time.deltaTime;
        int spawnNum = (int)(timer / spawnTime);
        timer %= spawnTime;

        // 在立方体范围内生成物体
        for (int i = 0; i < spawnNum && sum < maxNum; ++i)
        {
            Quaternion rotation = Quaternion.Euler(new Vector3(0, 90, 0));
            prefab.transform.rotation = rotation;
            Instantiate(prefab, boxRange.TransformPoint(RandomFloat(), RandomFloat(), RandomFloat()), Quaternion.identity, parent);
            ++sum;
        }
    }

    // 获取-0.5到0.5的随机值
    private float RandomFloat()
    {
        return Random.Range(-0.5f, 0.5f);
    }
}
