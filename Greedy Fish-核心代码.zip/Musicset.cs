﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Musicset : MonoBehaviour {
    //定义text
    Text musicvolshow;

    private int musicnum = 0;
    public AudioClip[] audioClips;
    public AudioSource music;

    // Use this for initialization
    void Start () {
        music = GetComponent<AudioSource>();
        music.clip = audioClips[musicnum];
        musicvolshow = transform.Find("Canvas").Find("Slider").Find("Volume Show").GetComponent<Text>();
    }
	
	// Update is called once per frame
	void Update () {
        //显示音乐的大小
        musicvolshow.text = (int)(music.volume * 100) + "%";
    }

/*    //播放音乐按钮
   public void Button_start() {
        //音乐
        AudioSource music = GetComponent<AudioSource>();
        music.Play();
    }*/

    //上一首音乐按钮
    public void Button_before() {
        musicnum--;
        if (musicnum <0)
        {
            musicnum = audioClips.Length-1;
        }
        if (music.isPlaying == true)
        {
            music.Stop();
        }
        music.clip = audioClips[musicnum];
        music.Play();
    }

    //暂停音乐
    public void Button_pause() {
        float time = music.time;
        if (music.isPlaying)
        {
            music.Pause();
        }
        else if (!music.isPlaying)
        {
            music.Play();
            music.time = time;
        }
    }

    /*    //关闭音乐按钮
        public void Button_close() {
            if (music.isPlaying)
            {
                music.Stop();
            }
        }*/

    //下一首音乐按钮
    public void Button_next()
    {
        musicnum++;
        if (musicnum > audioClips.Length - 1)
        {
            musicnum = 0;
        }
        if (music.isPlaying == true)
        {
            music.Stop();
        }
        music.clip = audioClips[musicnum];
        music.Play();
    }

    //控制音量
    public void MusicVolume(float musicvolume) {
        music.volume = musicvolume;
    }

}
