﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishMoveFree : MonoBehaviour {
    enum FishDir //设置朝向的枚举
    {
        left,
        right
    }
    FishDir dir; //申明一个方向控制鱼
    Vector3 target; //申明目标变量
    public float speed = 10; //设置鱼的速度
    public float angleSpeed = 5f; //鱼旋转的速度  因为面向目标点
    public bool isRotate = true;//是否旋转到面向目标点
    // Use this for initialization
    void Start()
    {
        float random = Random.value; //随机设置鱼的方向
        while (random == 0.5f) //循环判断random直到整个数字不等于0.5
        {
            random = Random.value;
        }
        if (random > 0.5f) //如果随机数大于0.5的情况和小于的情况
        {
            dir = FishDir.left;
        }
        else
        {
            dir = FishDir.right;
        }
        ChangeDir(); //调用改变方向的方法
        SetTarget(); //调用设置目标的方法
    }

    // Update is called once per frame
    void Update()
    {
        //转向
        if (isRotate)
        {
            Vector3 vec = (target - transform.position);
            Quaternion rotate = Quaternion.LookRotation(vec);
            transform.localRotation = Quaternion.Slerp(transform.localRotation, rotate, angleSpeed);
            if (Vector3.Angle(vec, transform.forward) < 0.1f)
            {
                isRotate = false;
            }
        }
        Move();
    }


    void ChangeDir()
    {
        Vector3 scale = transform.localScale; //设置scale变量
        if (dir == FishDir.left) //判断如果鱼儿的方向朝左时设置鱼儿的scale=1
        {
            scale.x = 1;
        }
        else
        {
            scale.x = -1;
        }
        transform.localScale = scale; //重新赋值
    }
    void SetTarget() //设置目标的方法
    {
        //float x = dir == FishDir.left ? -0.2f : 1.2f; //使用判断左右的方法为x的值赋值0或者1；
        //Vector3 viewPoint = new Vector3(x, Random.Range(-2,4), -Camera.main.transform.position.z); //生成一个点的位置坐标信息 不过他的这些信息只调用一次
        //target = Camera.main.ViewportToWorldPoint(viewPoint); //在世界坐标系中去实例化一个目标点
        //这里的x,y,z是对鱼在某个范围的限定 
        float x = Random.Range(-300, 300);
        float y = Random.Range(-35, 0);
        float z = Random.Range(-300, 300);
        target = new Vector3(x, y, z);
        isRotate = true;//判断是否进行移动方向的旋转
    }
    void Move() //设置移动的方法
    {
        transform.position = Vector3.MoveTowards(transform.position, target, speed * Time.deltaTime);
        if (Vector3.Distance(transform.position, target) == 0) //判断鱼是否到达边界位置
        {
            dir = dir == FishDir.left ? FishDir.right : FishDir.left; //控制鱼取得相反的方向
            ChangeDir();
            SetTarget();
        }
    }
}
