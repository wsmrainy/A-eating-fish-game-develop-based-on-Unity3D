﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Beeaten : MonoBehaviour {
    GameObject seawater;
	// Use this for initialization
	void Start () {
        seawater = GameObject.Find("sc01_res");
	}
	
	// Update is called once per frame
	void Update () {
        if (transform.position.y > (seawater.transform.position.y+15f)) {
            Destroy(this.gameObject);
        }
	}

    private void FixedUpdate()
    {
        GetComponent<Rigidbody>().velocity = Vector3.zero;
    }

    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag  == "MainFish")
        {
            Destroy(this.gameObject);
        }
    }
}
