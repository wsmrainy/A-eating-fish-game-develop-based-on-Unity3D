﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainFishMove : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        //WSAD控制前进后退旋转
        //旋转
        float steer = 20;
        float x = 0;
        if (Input.GetKey(KeyCode.A))
            x = -1;
        if (Input.GetKey(KeyCode.D))
            x = 1;
        transform.Rotate(0, x * steer * Time.deltaTime, 0);
        //前进后退
        float k_speed = 5f;
        float y = 0;
        if (Input.GetKey(KeyCode.W))
            y = 1;
        if (Input.GetKey(KeyCode.S))
            y = -1;
        Vector3 s = y * transform.forward * k_speed * Time.deltaTime;
        transform.transform.position += s;

        //鼠标控制上下左右
        //速度
        float m_speed = 0.5f;
        //首先获取到当前物体的屏幕坐标
        Camera camera;
        GameObject game = GameObject.Find("Camera");
        camera  = game.GetComponent<Camera>();
        GameObject fish = GameObject.Find("MainFish");
        Vector3 pos = camera.WorldToScreenPoint(fish.transform.position);

        //让鼠标的屏幕坐标的Z轴等于当前物体的屏幕坐标的Z轴，也就是相隔的距离
        Vector3 m_MousePos = new Vector3(Input.mousePosition.x, Input.mousePosition.y, pos.z);
        //将正确的鼠标屏幕坐标换成世界坐标交给物体
        Vector3 world = camera.ScreenToWorldPoint(m_MousePos) * m_speed;
        fish.transform.position = new Vector3(world.x, world.y, fish.transform.position.z);
    }
}
